<?php
$str = null;
for ($i = 0; $i < 20; $i++) {
    $str .= 'x';
    echo $str."<br>";
}