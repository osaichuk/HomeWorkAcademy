<?php
$arr = [1, 2, 3, 4, 5, 6, 7, 8, 9,];
foreach ($arr as $item) {
    if ($item == 3){
        echo "$item ";
    } elseif ($item == 6) {
        echo "$item ";
    } else {
        echo $item. "<br>";
    }
}