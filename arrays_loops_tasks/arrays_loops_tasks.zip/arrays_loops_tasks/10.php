<?php
for ($i = 11; $i<=33; $i++) {
    echo $i."<br>";
}