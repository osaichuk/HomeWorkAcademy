<?php
for ($b = 2;$b <= 10; $b++) {
    for ($a = 1; $a <= 10; $a++) {
        $c = $a * $b;
        echo "{$b} * {$a} = {$c}</br>";
    }
    echo "<hr>";
}