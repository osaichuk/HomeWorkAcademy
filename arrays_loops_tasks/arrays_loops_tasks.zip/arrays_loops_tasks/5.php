<?php
$arr = ['Коля' => '200', 'Вася' => '300', 'Петя' => '400',];
foreach ($arr as $key => $item) {
    echo "{$key} - зарплата {$item} долларов.<br>";
}