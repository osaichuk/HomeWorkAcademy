<?php
$arr = ['html', 'css', 'php', 'js', 'jq',];
foreach ($arr as $item) {
    echo $item;
    echo "<br>";
}