<?php

$name='Александр';
echo "Меня зовут: $name.";