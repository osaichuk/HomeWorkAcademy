<?php

$age=38;
echo 'Мне '."$age".' лет.';